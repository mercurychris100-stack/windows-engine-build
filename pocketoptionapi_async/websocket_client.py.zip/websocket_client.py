"""
Async WebSocket client for PocketOption API - Segment 1 of 3
"""

import asyncio
import json
import ssl
import time
from typing import Optional, Callable, Dict, Any, List, Deque, Union
from datetime import datetime
from collections import deque
import websockets
from websockets.exceptions import ConnectionClosed
from websockets.legacy.client import WebSocketClientProtocol
from loguru import logger

from .models import ConnectionInfo, ConnectionStatus, ServerTime
from .constants import CONNECTION_SETTINGS, DEFAULT_HEADERS
from .exceptions import WebSocketError, ConnectionError


class MessageBatcher:
    """Batch messages to improve performance"""

    def __init__(self, batch_size: int = 10, batch_timeout: float = 0.1):
        self.batch_size = batch_size
        self.batch_timeout = batch_timeout
        self.pending_messages: Deque[str] = deque()
        self._last_batch_time = time.time()
        self._batch_lock = asyncio.Lock()

    async def add_message(self, message: str) -> List[str]:
        """Add message to batch and return batch if ready"""
        async with self._batch_lock:
            self.pending_messages.append(message)
            current_time = time.time()

            # Check if batch is ready
            if (
                len(self.pending_messages) >= self.batch_size
                or current_time - self._last_batch_time >= self.batch_timeout
            ):
                batch = list(self.pending_messages)
                self.pending_messages.clear()
                self._last_batch_time = current_time
                return batch

            return []

    async def flush_batch(self) -> List[str]:
        """Force flush current batch"""
        async with self._batch_lock:
            if self.pending_messages:
                batch = list(self.pending_messages)
                self.pending_messages.clear()
                self._last_batch_time = time.time()
                return batch
            return []


class ConnectionPool:
    """Connection pool for better resource management"""

    def __init__(self, max_connections: int = 3):
        self.active_connections: Dict[str, WebSocketClientProtocol] = {}
        self.connection_stats: Dict[str, Dict[str, Any]] = {}
        self._pool_lock = asyncio.Lock()

    async def get_best_connection(self) -> Optional[str]:
        """Get the best performing connection URL"""
        async with self._pool_lock:
            if not self.connection_stats:
                return None

            best_url = min(
                self.connection_stats.keys(),
                key=lambda url: (
                    self.connection_stats[url].get("avg_response_time", float("inf")),
                    -self.connection_stats[url].get("success_rate", 0),
                ),
            )
            return best_url

    async def update_stats(self, url: str, response_time: float, success: bool):
        """Update connection statistics"""
        async with self._pool_lock:
            if url not in self.connection_stats:
                self.connection_stats[url] = {
                    "response_times": deque(maxlen=100),
                    "successes": 0,
                    "failures": 0,
                    "avg_response_time": 0,
                    "success_rate": 0,
                }

            stats = self.connection_stats[url]
            stats["response_times"].append(response_time)

            if success:
                stats["successes"] += 1
            else:
                stats["failures"] += 1

            if stats["response_times"]:
                stats["avg_response_time"] = sum(stats["response_times"]) / len(
                    stats["response_times"]
                )

            total_attempts = stats["successes"] + stats["failures"]
            if total_attempts > 0:
                stats["success_rate"] = stats["successes"] / total_attempts


class AsyncWebSocketClient:
    """
    Professional async WebSocket client for PocketOption
    """

    def __init__(self):
        self.websocket: Optional[WebSocketClientProtocol] = None
        self.connection_info: Optional[ConnectionInfo] = None
        self.server_time: Optional[ServerTime] = None
        self._ping_task: Optional[asyncio.Task] = None
        self._message_queue: asyncio.Queue = asyncio.Queue()
        self._event_handlers: Dict[str, List[Callable]] = {}
        self._running = False
        self._authenticated = False  # Guard flag — prevents ps messages before auth completes
        self._auto_reconnect = True   # Set to False externally to disable internal reconnect loop
        self._reconnect_attempts = 0
        self._max_reconnect_attempts = CONNECTION_SETTINGS["max_reconnect_attempts"]

        # Performance improvements
        self._message_batcher = MessageBatcher()
        self._connection_pool = ConnectionPool()
        self._rate_limiter = asyncio.Semaphore(10)
        self._message_cache: Dict[str, Any] = {}
        self._cache_ttl = 5.0

        # Message processing optimization handlers
        self._message_handlers = {
            "0": self._handle_initial_message,
            "2": self._handle_ping_message,
            "40": self._handle_connection_message,
            "451-[": self._handle_json_message_wrapper,
            "42": self._handle_auth_message,
            "[[5,": self._handle_payout_message,
        }
    # Async WebSocket client for PocketOption API - Segment 2 of 3

    async def connect(self, urls: List[str], ssid: str) -> bool:
        """Connect to PocketOption WebSocket with fallback URLs"""
        for url in urls:
            try:
                logger.info(f"Attempting to connect to {url}")

                ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE

                ws = await asyncio.wait_for(
                    websockets.connect(
                        url,
                        ssl=ssl_context,
                        extra_headers=DEFAULT_HEADERS,
                        ping_interval=CONNECTION_SETTINGS["ping_interval"],
                        ping_timeout=CONNECTION_SETTINGS["ping_timeout"],
                        close_timeout=CONNECTION_SETTINGS["close_timeout"],
                    ),
                    timeout=10.0,
                )
                self.websocket = ws  
                region = self._extract_region_from_url(url)
                self.connection_info = ConnectionInfo(
                    url=url,
                    region=region,
                    status=ConnectionStatus.CONNECTED,
                    connected_at=datetime.now(),
                    reconnect_attempts=self._reconnect_attempts,
                )

                logger.info(f"Connected to {region} region successfully")
                self._running = True

                await self._send_handshake(ssid)
                await self._start_background_tasks()

                self._reconnect_attempts = 0
                return True

            except Exception as e:
                logger.warning(f"Failed to connect to {url}: {e}")
                if self.websocket:
                    await self.websocket.close()
                    self.websocket = None
                continue

        raise ConnectionError("Failed to connect to any WebSocket endpoint")

    async def receive_messages(self) -> None:
        """Continuously receive and process messages"""
        try:
            while self._running and self.websocket:
                try:
                    message = await asyncio.wait_for(
                        self.websocket.recv(),
                        timeout=CONNECTION_SETTINGS["message_timeout"],
                    )
                    await self._process_message(message)

                except asyncio.TimeoutError:
                    logger.warning("Message receive timeout")
                    continue
                except ConnectionClosed:
                    logger.warning("WebSocket connection closed")
                    await self._handle_disconnect()
                    break

        except Exception as e:
            logger.error(f"Error in message receiving: {e}")
            await self._handle_disconnect()

    def add_event_handler(self, event: str, handler: Callable) -> None:
        """Add event handler"""
        if event not in self._event_handlers:
            self._event_handlers[event] = []
        self._event_handlers[event].append(handler)

    def remove_event_handler(self, event: str, handler: Callable) -> None:
        """Remove event handler"""
        if event in self._event_handlers:
            try:
                self._event_handlers[event].remove(handler)
            except ValueError:
                pass

    async def _send_handshake(self, ssid: str) -> None:
        """Send initial handshake messages"""
        try:
            logger.debug("Waiting for initial handshake message...")
            if not self.websocket:
                raise WebSocketError("WebSocket is not connected during handshake")
            initial_message = await asyncio.wait_for(
                self.websocket.recv(), timeout=10.0
            )
            logger.debug(f"Received initial: {initial_message}")

            if isinstance(initial_message, memoryview):
                initial_message = bytes(initial_message).decode("utf-8")
            elif isinstance(initial_message, (bytes, bytearray)):
                initial_message = initial_message.decode("utf-8")

            if initial_message.startswith("0") and "sid" in initial_message:
                await self.send_message("40")
                logger.debug("Sent '40' response")

                conn_message = await asyncio.wait_for(
                    self.websocket.recv(), timeout=10.0
                )
                logger.debug(f"Received connection: {conn_message}")

                if isinstance(conn_message, memoryview):
                    conn_message_str = bytes(conn_message).decode("utf-8")
                elif isinstance(conn_message, (bytes, bytearray)):
                    conn_message_str = conn_message.decode("utf-8")
                else:
                    conn_message_str = conn_message
                if conn_message_str.startswith("40") and "sid" in conn_message_str:
                    await self.send_message(ssid)
                    logger.debug("Sent SSID authentication")
                else:
                    logger.warning(f"Unexpected connection message format: {conn_message}")
            else:
                logger.warning(f"Unexpected initial message format: {initial_message}")

            logger.debug("Handshake sequence completed")
        except asyncio.TimeoutError:
            logger.error("Handshake timeout - server didn't respond as expected")
            raise WebSocketError("Handshake timeout")
        except Exception as e:
            logger.error(f"Handshake failed: {e}")
            raise

    async def _start_background_tasks(self) -> None:
        """Start background tasks"""
        self._ping_task = asyncio.create_task(self._ping_loop())
        asyncio.create_task(self.receive_messages())

    async def _ping_loop(self) -> None:
        """Send periodic ping messages — only after authentication is confirmed.
        
        Sending 42["ps"] during handshake causes server to disconnect with code 1005.
        We wait one full ping interval before starting, then only send if authenticated.
        """
        # Initial wait — let handshake and auth complete before first ping
        await asyncio.sleep(CONNECTION_SETTINGS["ping_interval"])

        while self._running and self.websocket:
            try:
                await asyncio.sleep(CONNECTION_SETTINGS["ping_interval"])

                # GUARD: Only send ps after authentication is confirmed
                if self.websocket and not self.websocket.closed and self._authenticated:
                    await self.send_message('42["ps"]')

                    if self.connection_info:
                        self.connection_info = ConnectionInfo(
                            url=self.connection_info.url,
                            region=self.connection_info.region,
                            status=self.connection_info.status,
                            connected_at=self.connection_info.connected_at,
                            last_ping=datetime.now(),
                            reconnect_attempts=self.connection_info.reconnect_attempts,
                        )

            except Exception as e:
                logger.error(f"Ping failed: {e}")
                break

    async def _process_message(self, message) -> None:
        """Process incoming WebSocket message (including modern 42 interceptor)"""
        try:
            if isinstance(message, bytes):
                decoded_message = message.decode("utf-8")
                try:
                    json_data = json.loads(decoded_message)
                    logger.debug(f"Received JSON bytes message: {json_data}")

                    if "balance" in json_data:
                        balance_data = {
                            "balance": json_data["balance"],
                            "currency": "USD",
                            "is_demo": bool(json_data.get("isDemo", 1)),
                        }
                        if "uid" in json_data:
                            balance_data["uid"] = json_data["uid"]

                        logger.info(f"Balance data received: {balance_data}")
                        await self._emit_event("balance_data", balance_data)

                    elif "requestId" in json_data and json_data["requestId"] == "buy":
                        await self._emit_event("order_data", json_data)
                    else:
                        await self._emit_event("json_data", json_data)

                except json.JSONDecodeError:
                    logger.debug(f"Non-JSON bytes message: {decoded_message[:100]}...")
                return

            if isinstance(message, bytes):
                message = message.decode("utf-8")

            logger.debug(f"Received message: {message}")

            # --- INJECTED INTERCEPTOR: Routes 42 stream payloads straight to parser ---
            if message.startswith("42"):
                if '"payout"' in message or '"payout_update"' in message or '"ps"' in message:
                    try:
                        json_part = message[2:]
                        parsed_arr = json.loads(json_part)
                        if isinstance(parsed_arr, list) and len(parsed_arr) >= 2:
                            if parsed_arr[0] in ["payout", "payout_update", "payouts", "updateStream"]:
                                await self._handle_payout_message(parsed_arr)
                                return
                    except Exception:
                        pass

            if message.startswith("0") and "sid" in message:
                await self.send_message("40")
            elif message == "2":
                await self.send_message("3")
            
            # --- INJECTED DISCONNECT INTERCEPTOR ---
            # Catches explicit broker 41 kick frames to prevent retry loop desyncs
            elif message == "41":
                logger.warning("⚠️ Broker triggered explicitly targeted disconnect code (41). Killing ghost thread session.")
                await self._handle_disconnect()
                return
            # ---------------------------------------

            elif message.startswith("40") and "sid" in message:
                await self._emit_event("connected", {})
            elif message.startswith("451-["):
                json_part = message.split("-", 1)[1]
                data = json.loads(json_part)
                await self._handle_json_message(data)
            elif message.startswith("42") and "NotAuthorized" in message:
                logger.error("Authentication failed: Server rejected SSID.")
                await self._emit_event("auth_error", {"message": "Invalid or expired SSID"})

        except Exception as e:
            logger.error(f"Error processing message: {e}")


    # Async WebSocket client for PocketOption API - Segment 3 of 3 (Part A)

    async def _handle_payout_message(self, message: Union[str, Dict[str, Any], List[Any]]) -> None:
        """Handles telemetry parsing across both legacy [[5, ...]] and flat dictionary updates."""
        try:
            if isinstance(message, dict):
                await self._process_flat_payout_dict(message)
                return
            elif isinstance(message, list):
                if len(message) >= 2 and isinstance(message, dict):
                    await self._process_flat_payout_dict(message)
                    return
                for entry in message:
                    if isinstance(entry, dict):
                        await self._process_flat_payout_dict(entry)
                return

            message_str = str(message).strip()
            if message_str.startswith("42[") or '"symbol"' in message_str:
                try:
                    clean_str = message_str[2:] if message_str.startswith("42") else message_str
                    parsed_json = json.loads(clean_str)
                    if isinstance(parsed_json, list):
                        for item in parsed_json:
                            if isinstance(item, dict):
                                await self._process_flat_payout_dict(item)
                        return
                    elif isinstance(parsed_json, dict):
                        await self._process_flat_payout_dict(parsed_json)
                        return
                except Exception:
                    pass

            json_start_index = message_str.find("[", message_str.find("[") + 1)
            json_end_index = message_str.rfind("]")

            if json_start_index == -1 or json_end_index == -1:
                try:
                    parsed_direct = json.loads(message_str)
                    if isinstance(parsed_direct, dict):
                        await self._process_flat_payout_dict(parsed_direct)
                        return
                except Exception:
                    pass
                return

            json_str = message_str[json_start_index : json_end_index + 1]
            data: List[List[Any]] = json.loads(json_str)

            for asset_data in data:
                if isinstance(asset_data, list) and len(asset_data) > 5:
                    try:
                        payout_info = {
                            "symbol": str(asset_data),
                            "payout": asset_data,
                            "id": asset_data,
                            "name": asset_data,
                            "type": asset_data,
                        }
                        await self._emit_event("payout_update", payout_info)
                    except Exception as inner_err:
                        logger.error(f"Error handling legacy matrix row: {inner_err}")
                        
        except json.JSONDecodeError as e:
            logger.error(f"Failed to decode JSON from payout payload: {e}")
        except Exception as e:
            logger.error(f"Error executing _handle_payout_message loop: {e}")

    async def _process_flat_payout_dict(self, data_dict: Dict[str, Any]) -> None:
        """Helper to process flat key-value websocket structures cleanly"""
        try:
            symbol = data_dict.get("symbol") or data_dict.get("asset") or data_dict.get("active")
            payout = data_dict.get("payout") or data_dict.get("percent") or data_dict.get("rate")
            if symbol and payout is not None:
                payout_info = {
                    "symbol": str(symbol).strip(),
                    "payout": payout,
                    "id": data_dict.get("id", 0),
                    "name": data_dict.get("name", str(symbol)),
                    "type": data_dict.get("type", "forex/otc")
                }
                await self._emit_event("payout_update", payout_info)
        except Exception as e:
            logger.error(f"Error processing sub-dictionary mapping elements: {e}")

    # Async WebSocket client for PocketOption API - Segment 3 of 3 (Part B)

    async def disconnect(self):
        """Gracefully disconnect from WebSocket"""
        logger.info("Disconnecting from WebSocket")
        self._running = False

        if self._ping_task and not self._ping_task.done():
            self._ping_task.cancel()
            try: await self._ping_task
            except asyncio.CancelledError: pass

        if self.websocket:
            await self.websocket.close()
            self.websocket = None

        if self.connection_info:
            self.connection_info = ConnectionInfo(
                url=self.connection_info.url,
                region=self.connection_info.region,
                status=ConnectionStatus.DISCONNECTED,
                connected_at=self.connection_info.connected_at,
                reconnect_attempts=self.connection_info.reconnect_attempts,
            )

    async def send_message(self, message: str) -> None:
        """Send message to WebSocket"""
        if not self.websocket or self.websocket.closed:
            raise WebSocketError("WebSocket is not connected")
        try:
            await self.websocket.send(message)
            logger.debug(f"Sent message: {message}")
        except Exception as e:
            logger.error(f"Failed to send message: {e}")
            raise WebSocketError(f"Failed to send message: {e}")

    async def send_message_optimized(self, message: str) -> None:
        """Send message with batching optimization"""
        async with self._rate_limiter:
            if not self.websocket or self.websocket.closed:
                raise WebSocketError("WebSocket is not connected")
            try:
                start_time = time.time()
                batch = await self._message_batcher.add_message(message)
                if batch:
                    for msg in batch:
                        await self.websocket.send(msg)
                        logger.debug(f"Sent batched message: {msg}")

                response_time = time.time() - start_time
                if self.connection_info:
                    await self._connection_pool.update_stats(self.connection_info.url, response_time, True)
            except Exception as e:
                logger.error(f"Failed to send message: {e}")
                if self.connection_info:
                    await self._connection_pool.update_stats(self.connection_info.url, 0, False)
                raise WebSocketError(f"Failed to send message: {e}")

    async def _handle_initial_message(self, message: str) -> None:
        if "sid" in message: await self.send_message("40")

    async def _handle_ping_message(self, message: str) -> None:
        await self.send_message("3")

    async def _handle_connection_message(self, message: str) -> None:
        if "sid" in message: await self._emit_event("connected", {})

    async def _handle_json_message_wrapper(self, message: str) -> None:
        json_part = message.split("-", 1)
        data = json.loads(json_part)
        await self._handle_json_message(data)

    async def _handle_auth_message(self, message: str) -> None:
        if "NotAuthorized" in message:
            logger.error("Authentication failed: Server rejected SSID.")
            await self._emit_event("auth_error", {"message": "Invalid or expired SSID"})

    async def _process_message_optimized(self, message) -> None:
        """Process incoming WebSocket message with optimization routing checks"""
        try:
            if isinstance(message, bytes):
                message = message.decode("utf-8")

            logger.debug(f"Received message: {message}")

            if message.startswith("42") and ('"payout"' in message or '"updateStream"' in message):
                try:
                    json_p = message[2:]
                    parsed_a = json.loads(json_p)
                    if isinstance(parsed_a, list) and len(parsed_a) >= 2:
                        await self._handle_payout_message(parsed_a)
                        return
                except Exception:
                    pass

            # --- INJECTED DISCONNECT INTERCEPTOR (OPTIMIZED PATH) ---
            # Catches explicit broker 41 kick frames to prevent cache route pollution
            if message == "41":
                logger.warning("⚠️ Broker triggered explicitly targeted disconnect code (41). Killing optimized ghost thread session.")
                await self._handle_disconnect()
                return
            # --------------------------------------------------------

            message_hash = hash(message)
            cached_time = self._message_cache.get(f"{message_hash}_time")

            if cached_time and time.time() - cached_time < self._cache_ttl:
                cached_result = self._message_cache.get(str(message_hash))
                if cached_result:
                    await self._emit_event("cached_message", cached_result)
                    return

            for prefix, handler in self._message_handlers.items():
                if message.startswith(prefix):
                    await handler(message)
                    break
            else:
                logger.warning(f"Unknown message type: {message[:20]}...")

            self._message_cache[str(message_hash)] = {"processed": True, "type": "unknown"}
            self._message_cache[f"{message_hash}_time"] = time.time()

        except Exception as e:
            logger.error(f"Error processing message: {e}")

    async def _handle_json_message(self, data: List[Any]) -> None:
        if not data or len(data) < 1: return
        event_type = data
        event_data = data if len(data) > 1 else {}

        if event_type == "successauth":
            self._authenticated = True  # Unlock ping loop — auth confirmed
            await self._emit_event("authenticated", event_data)
        elif event_type == "successupdateBalance":
            await self._emit_event("balance_updated", event_data)
        elif event_type == "successopenOrder":
            await self._emit_event("order_opened", event_data)
        elif event_type == "successcloseOrder":
            await self._emit_event("order_closed", event_data)
        elif event_type == "updateStream":
            await self._emit_event("stream_update", event_data)
        elif event_type == "loadHistoryPeriod":
            await self._emit_event("candles_received", event_data)
        elif event_type == "updateHistoryNew":
            await self._emit_event("history_update", event_data)
        else:
            await self._emit_event("unknown_event", {"type": event_type, "data": event_data})

    async def _emit_event(self, event: str, data: Dict[str, Any]) -> None:
        if event in self._event_handlers:
            for handler in self._event_handlers[event]:
                try:
                    if asyncio.iscoroutinefunction(handler): await handler(data)
                    else: handler(data)
                except Exception as e:
                    logger.error(f"Error in event handler for {event}: {e}")

    async def _handle_disconnect(self) -> None:
        if self.connection_info:
            self.connection_info = ConnectionInfo(
                url=self.connection_info.url,
                region=self.connection_info.region,
                status=ConnectionStatus.DISCONNECTED,
                connected_at=self.connection_info.connected_at,
                last_ping=self.connection_info.last_ping,
                reconnect_attempts=self.connection_info.reconnect_attempts,
            )
        self._authenticated = False  # Reset auth flag on disconnect
        await self._emit_event("disconnected", {})
        
        # GUARD: If auto_reconnect is disabled, do not attempt internal reconnect.
        # The external connection_monitor in engine.py is the single source of truth.
        if hasattr(self, '_auto_reconnect') and not self._auto_reconnect:
            logger.info("Auto-reconnect disabled — handing control to external connection manager.")
            return
            
        if self._reconnect_attempts < self._max_reconnect_attempts:
            self._reconnect_attempts += 1
            logger.info(f"Attempting reconnection {self._reconnect_attempts}/{self._max_reconnect_attempts}")
            await asyncio.sleep(CONNECTION_SETTINGS["reconnect_delay"])

    def _extract_region_from_url(self, url: str) -> str:
        try:
            parts = url.split("//").split(".")
            if "api-" in parts: return parts.replace("api-", "").upper()
            elif "demo" in parts: return "DEMO"
            else: return "UNKNOWN"
        except Exception: return "UNKNOWN"

    @property
    def is_connected(self) -> bool:
        return (
            self.websocket is not None
            and not self.websocket.closed
            and self.connection_info is not None
            and self.connection_info.status == ConnectionStatus.CONNECTED
        )
